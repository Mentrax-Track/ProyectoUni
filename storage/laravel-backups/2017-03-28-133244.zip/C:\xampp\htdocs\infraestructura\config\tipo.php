<?php 

return array(

    'tipos' => [
        'supervisor'        => 'supervisor',
        'chofer'            => 'chofer',
        'mecanico'          => 'mecanico',
        'mensajero'          => 'mensajero',
    ],
    'tipose' => [
        'gasolina'=> 'Gasolina',
        'diesel'  => 'Diesel',
        'gnv'     => 'GNV',
    ]
)
?> 