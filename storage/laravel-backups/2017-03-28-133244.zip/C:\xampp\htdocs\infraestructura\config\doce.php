<?php 

return array(

    'doces' => [
        'encargado'    => 'encargado',
    ]
)
?> 