<?php 

return array(

    'estados' => [
        'optimo'        => 'Óptimo',
        'mantenimiento' => 'Mantenimiento',
        'desuso'        => 'Desuso',
    ]
)
?>