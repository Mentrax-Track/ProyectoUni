<?php

namespace Infraestructura\Events;

abstract class Event
{
    //
}
