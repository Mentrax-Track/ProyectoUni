<?php 

return array(

    'mante' => [
         'A) Motor'         =>'A) Motor',
         'B) Caja de Cambio'=>'B) Caja de Cambio',
         'C) Ruedas'        =>'C) Ruedas',
         'D) Muelles o espirales'=>'D) Muelles o espirales',
         'E) Dirección'          =>'E) Dirección',
         'F) Caja de dirección'  =>'F) Caja de dirección',
         'G) Soporte Motor'      =>'G) Soporte Motor',
         'H) Chasis'             =>'H) Chasis',
         'I) Sistema eléctrico'  =>'I) Sistema eléctrico',
         'J) Iluminación'        =>'J) Iluminación',
         'K) Toca cintas'        =>'K) Toca cintas',
         'L) Frenos'             =>'L) Frenos',
         'M) Amortiguadores'     =>'M) Amortiguadores',
         'N) Bomba de gasolina'  =>'N) Bomba de gasolina'
    ],
    'vehiculo' => [
         'A) Cambio de disco de embriague'               =>'A) Cambio de disco de embrague',
         'B) Cambio de la prensade embrague'             =>'B) Cambio de la prensa de embrague',
         'C) Cambio de rodamiento desplazador'           =>'C) Cambio de rodamiento desplazador',
         'D) Cambio de los seguros del freno de mano'    =>'D) Cambio de los seguros del freno de mano',
         'E) Cambio de resortes de freno de mano'        =>'E) Cambio de resortes de freno de mano',
         'F) Cambio de bateria'                          =>'F) Cambio de bateria',
         'G) Cambio de aceite de motor'                  =>'G) Cambio de aceite de motor',
         'H) Cambio de filtro de aceite'                 =>'H) Cambio de filtro de aceite',
         'J) Cambio de filtro de combustible'            =>'J) Cambio de filtro de combustible',
         'K) Cambio'                                    =>'K) Cambio',
         'L) Cambio de Filtro'                          =>'L) Cambio de Filtro',
         'M) Cambio de pastillas'                       =>'M) Cambio de pastillas',
         'N) Compra de llantas'                         =>'N) Compra de llantas',
         'O) Liquido de Freno'                          =>'O) Liquido de Freno'
    ]
)


?> 