
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accesorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accesorios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `solicitud` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `solicitud_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `accesorios_solicitud_id_foreign` (`solicitud_id`),
  CONSTRAINT `accesorios_solicitud_id_foreign` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accesorios` WRITE;
/*!40000 ALTER TABLE `accesorios` DISABLE KEYS */;
/*!40000 ALTER TABLE `accesorios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `capital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capital` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hay` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `monto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `capital` WRITE;
/*!40000 ALTER TABLE `capital` DISABLE KEYS */;
/*!40000 ALTER TABLE `capital` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `destino_viaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `destino_viaje` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `destino_id` int(10) unsigned NOT NULL,
  `viaje_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `destino_viaje_destino_id_foreign` (`destino_id`),
  KEY `destino_viaje_viaje_id_foreign` (`viaje_id`),
  CONSTRAINT `destino_viaje_destino_id_foreign` FOREIGN KEY (`destino_id`) REFERENCES `destinos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `destino_viaje_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `destino_viaje` WRITE;
/*!40000 ALTER TABLE `destino_viaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `destino_viaje` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `destinos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `destinos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dep_inicio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `origen` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `destino` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dep_final` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ruta` text COLLATE utf8_unicode_ci NOT NULL,
  `kilometraje` double(8,2) NOT NULL,
  `tiempo` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `destinos` WRITE;
/*!40000 ALTER TABLE `destinos` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `devoluciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devoluciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `serial` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `insertador` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mecanico_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `devoluciones_mecanico_id_foreign` (`mecanico_id`),
  CONSTRAINT `devoluciones_mecanico_id_foreign` FOREIGN KEY (`mecanico_id`) REFERENCES `mecanicos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `devoluciones` WRITE;
/*!40000 ALTER TABLE `devoluciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `devoluciones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `diesel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diesel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `litros` int(11) NOT NULL,
  `preciod` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `totald` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `diesel` WRITE;
/*!40000 ALTER TABLE `diesel` DISABLE KEYS */;
/*!40000 ALTER TABLE `diesel` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `entidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entidades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `facultad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `carrera` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `materia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sigla` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `entidades_user_id_foreign` (`user_id`),
  CONSTRAINT `entidades_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `entidades` WRITE;
/*!40000 ALTER TABLE `entidades` DISABLE KEYS */;
/*!40000 ALTER TABLE `entidades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `excepciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `excepciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chofer_id` int(11) NOT NULL,
  `tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lugar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `roles_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `excepciones_roles_id_foreign` (`roles_id`),
  CONSTRAINT `excepciones_roles_id_foreign` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `excepciones` WRITE;
/*!40000 ALTER TABLE `excepciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `excepciones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `gasolina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gasolina` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `litros` int(11) NOT NULL,
  `preciog` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `totalg` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `gasolina` WRITE;
/*!40000 ALTER TABLE `gasolina` DISABLE KEYS */;
/*!40000 ALTER TABLE `gasolina` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `gnv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gnv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `litros` int(11) NOT NULL,
  `precion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `totaln` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `gnv` WRITE;
/*!40000 ALTER TABLE `gnv` DISABLE KEYS */;
/*!40000 ALTER TABLE `gnv` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `hidrocarburos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hidrocarburos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npedido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `factura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vehiculo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `combustible` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gasolina` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `diesel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gnv` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `litros` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_recargue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `hidrocarburos` WRITE;
/*!40000 ALTER TABLE `hidrocarburos` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidrocarburos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `informesdebolu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informesdebolu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `combus` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `peaje` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `impre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `totalcopeim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `informesviaje_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `informesdebolu_informesviaje_id_foreign` (`informesviaje_id`),
  CONSTRAINT `informesdebolu_informesviaje_id_foreign` FOREIGN KEY (`informesviaje_id`) REFERENCES `informesviajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `informesdebolu` WRITE;
/*!40000 ALTER TABLE `informesdebolu` DISABLE KEYS */;
/*!40000 ALTER TABLE `informesdebolu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `informesvehi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informesvehi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mantenimiento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `informesviaje_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `informesvehi_informesviaje_id_foreign` (`informesviaje_id`),
  CONSTRAINT `informesvehi_informesviaje_id_foreign` FOREIGN KEY (`informesviaje_id`) REFERENCES `informesviajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `informesvehi` WRITE;
/*!40000 ALTER TABLE `informesvehi` DISABLE KEYS */;
/*!40000 ALTER TABLE `informesvehi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `informesviajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informesviajes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chofer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `encargado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `entidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechapartida` date NOT NULL,
  `kilopartida` int(11) NOT NULL,
  `tiempopartida` time NOT NULL,
  `fechallegada` date NOT NULL,
  `kilollegada` int(11) NOT NULL,
  `tiempollegada` time NOT NULL,
  `viaticoa` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `viaticob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `viaticoc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pasajeros` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kmtotal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recargue1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `compra1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recargue2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `compra2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recargue3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `compra3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `combustotalu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `combustotalco` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `montope` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `montoim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `totalpeim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `delegacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripmante` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recomendacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `informesviajes` WRITE;
/*!40000 ALTER TABLE `informesviajes` DISABLE KEYS */;
/*!40000 ALTER TABLE `informesviajes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `infoviaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infoviaje` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `viaje_id` int(10) unsigned NOT NULL,
  `informeviaje_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `infoviaje_viaje_id_foreign` (`viaje_id`),
  KEY `infoviaje_informeviaje_id_foreign` (`informeviaje_id`),
  CONSTRAINT `infoviaje_informeviaje_id_foreign` FOREIGN KEY (`informeviaje_id`) REFERENCES `informesviajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `infoviaje_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `infoviaje` WRITE;
/*!40000 ALTER TABLE `infoviaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `infoviaje` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kilomecanicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kilomecanicos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hay` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aumento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `mecanico_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `kilomecanicos_vehiculo_id_foreign` (`vehiculo_id`),
  KEY `kilomecanicos_mecanico_id_foreign` (`mecanico_id`),
  CONSTRAINT `kilomecanicos_mecanico_id_foreign` FOREIGN KEY (`mecanico_id`) REFERENCES `mecanicos` (`id`),
  CONSTRAINT `kilomecanicos_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kilomecanicos` WRITE;
/*!40000 ALTER TABLE `kilomecanicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `kilomecanicos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kilomeinformes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kilomeinformes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hay` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aumento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `informe_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `kilomeinformes_vehiculo_id_foreign` (`vehiculo_id`),
  KEY `kilomeinformes_informe_id_foreign` (`informe_id`),
  CONSTRAINT `kilomeinformes_informe_id_foreign` FOREIGN KEY (`informe_id`) REFERENCES `informesviajes` (`id`),
  CONSTRAINT `kilomeinformes_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kilomeinformes` WRITE;
/*!40000 ALTER TABLE `kilomeinformes` DISABLE KEYS */;
/*!40000 ALTER TABLE `kilomeinformes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mapas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mapas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lat` double(20,10) NOT NULL,
  `lng` double(20,10) NOT NULL,
  `insertador` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `destino_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mapas_destino_id_unique` (`destino_id`),
  CONSTRAINT `mapas_destino_id_foreign` FOREIGN KEY (`destino_id`) REFERENCES `destinos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mapas` WRITE;
/*!40000 ALTER TABLE `mapas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mapas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `marcas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marcas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marca` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chasis` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `motor` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cilindrada` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `modelo_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `marcas_modelo_id_foreign` (`modelo_id`),
  CONSTRAINT `marcas_modelo_id_foreign` FOREIGN KEY (`modelo_id`) REFERENCES `modelos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `marcas` WRITE;
/*!40000 ALTER TABLE `marcas` DISABLE KEYS */;
/*!40000 ALTER TABLE `marcas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mecanicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mecanicos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `trabajo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `marca` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kilometraje` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `insertador` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `solicitud_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `mecanicos_solicitud_id_foreign` (`solicitud_id`),
  CONSTRAINT `mecanicos_solicitud_id_foreign` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mecanicos` WRITE;
/*!40000 ALTER TABLE `mecanicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `mecanicos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_08_15_164138_create_reserva_table',1),('2016_08_19_094448_create_vehiculos_table',1),('2016_08_19_095003_create_user_vehiculo_table',1),('2016_08_19_155440_create_viajes_table',1),('2016_08_19_155720_create_user_viaje_table',1),('2016_08_19_161547_create_vehiculo_viaje_table',1),('2016_08_19_162455_create_destino_table',1),('2016_08_19_162742_create_destino_viaje_table',1),('2016_08_24_091243_create_rutas_table',1),('2016_09_20_085833_create_presupuesto_table',1),('2016_10_12_173123_create_roles_table',1),('2016_10_17_032743_create_rolviaje_table',1),('2016_10_26_172359_create_presupuesto_dia_table',1),('2016_10_28_103030_create_salidas_table',1),('2016_11_11_164705_create_informeviaje_table',1),('2016_11_11_164826_create_infoviaje_table',1),('2016_11_17_150529_create_informedebolu_table',1),('2016_11_18_100347_create_informesViehis_table',1),('2016_11_23_210205_create_entidad_table',1),('2016_11_23_210351_create_celular_table',1),('2016_11_23_210459_create_email_table',1),('2016_11_30_190108_create_vehiculo_modelo_table',1),('2016_11_30_190457_create_vehiculo_marca_table',1),('2016_12_04_024052_create_provincias_table',1),('2016_12_04_024108_create_municipios_table',1),('2016_12_04_113257_create_mapas_table',1),('2016_12_13_093115_create_Solicitud_table',1),('2016_12_13_095922_create_Accesorios_table',1),('2016_12_13_173401_create_Mecanico_table',1),('2017_02_17_024012_create_excepciones_roles',1),('2017_02_27_101647_create_recargue_table',1),('2017_02_27_103114_create_gasolina_table',1),('2017_02_27_103128_create_diesel_table',1),('2017_02_27_103140_create_gnv_table',1),('2017_02_28_102623_create_pedidos_table',1),('2017_03_02_113553_add_recargues_table',1),('2017_03_02_114545_create_hidrocarburos_table',1),('2017_03_02_114650_add_hidrocarburos_table',1),('2017_03_02_130348_create_capital_table',1),('2017_03_03_004745_create_kiloinfomes_table',1),('2017_03_03_033346_create_kilomecanico_table',1),('2017_03_14_023521_create_peticion_table',1),('2017_03_15_004649_create_devoluciones_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `modelos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modelo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipoe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kilometraje` double(8,2) NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `modelos_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `modelos_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `modelos` WRITE;
/*!40000 ALTER TABLE `modelos` DISABLE KEYS */;
/*!40000 ALTER TABLE `modelos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `provincia_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `municipios_provincia_id_foreign` (`provincia_id`),
  CONSTRAINT `municipios_provincia_id_foreign` FOREIGN KEY (`provincia_id`) REFERENCES `provincias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `municipios` WRITE;
/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gasolina_id` int(10) unsigned NOT NULL,
  `diesel_id` int(10) unsigned NOT NULL,
  `gnv_id` int(10) unsigned NOT NULL,
  `recargue_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pedidos_recargue_id_foreign` (`recargue_id`),
  KEY `pedidos_gasolina_id_foreign` (`gasolina_id`),
  KEY `pedidos_diesel_id_foreign` (`diesel_id`),
  KEY `pedidos_gnv_id_foreign` (`gnv_id`),
  CONSTRAINT `pedidos_diesel_id_foreign` FOREIGN KEY (`diesel_id`) REFERENCES `diesel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pedidos_gasolina_id_foreign` FOREIGN KEY (`gasolina_id`) REFERENCES `gasolina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pedidos_gnv_id_foreign` FOREIGN KEY (`gnv_id`) REFERENCES `gnv` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pedidos_recargue_id_foreign` FOREIGN KEY (`recargue_id`) REFERENCES `recargues` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `peticiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peticiones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orden` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `insertador` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `solicitud_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `peticiones_solicitud_id_foreign` (`solicitud_id`),
  CONSTRAINT `peticiones_solicitud_id_foreign` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `peticiones` WRITE;
/*!40000 ALTER TABLE `peticiones` DISABLE KEYS */;
/*!40000 ALTER TABLE `peticiones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `presudias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presudias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo` int(11) NOT NULL,
  `chofer` int(11) NOT NULL,
  `encargado` int(11) NOT NULL,
  `entidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `combustible` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `litros` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vuelta` int(11) NOT NULL,
  `fechavu` date NOT NULL,
  `motivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `viaje_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `presudias_viaje_id_foreign` (`viaje_id`),
  CONSTRAINT `presudias_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `presudias` WRITE;
/*!40000 ALTER TABLE `presudias` DISABLE KEYS */;
/*!40000 ALTER TABLE `presudias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `presupuestos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presupuestos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo` int(11) NOT NULL,
  `chofer` int(11) NOT NULL,
  `encargado` int(11) NOT NULL,
  `entidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_sa` date NOT NULL,
  `division1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `viaje_id` int(10) unsigned NOT NULL,
  `combustible1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `carta1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total1C` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total2VC` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total3VP` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total4VF` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad5` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio5` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total5P` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad6` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio6` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total6M` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad7` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio7` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total7G` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total8T` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `responsable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `materia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sigla` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ndocentes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hsalida` time NOT NULL,
  `hllegada` time NOT NULL,
  `p1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `r1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `t1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `p2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `r2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `t2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `p3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `t3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `diferencia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nota` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `presupuestos_viaje_id_foreign` (`viaje_id`),
  CONSTRAINT `presupuestos_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `presupuestos` WRITE;
/*!40000 ALTER TABLE `presupuestos` DISABLE KEYS */;
/*!40000 ALTER TABLE `presupuestos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `provincias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `departamento_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `provincias_departamento_id_foreign` (`departamento_id`),
  CONSTRAINT `provincias_departamento_id_foreign` FOREIGN KEY (`departamento_id`) REFERENCES `destinos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `provincias` WRITE;
/*!40000 ALTER TABLE `provincias` DISABLE KEYS */;
/*!40000 ALTER TABLE `provincias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `recargues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recargues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(11) NOT NULL,
  `combustible` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `factura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `recargues` WRITE;
/*!40000 ALTER TABLE `recargues` DISABLE KEYS */;
/*!40000 ALTER TABLE `recargues` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `objetivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pasajeros` int(11) NOT NULL,
  `fecha_inicial` date NOT NULL,
  `fecha_final` date NOT NULL,
  `dias` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `reservas_user_id_foreign` (`user_id`),
  CONSTRAINT `reservas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reservas` WRITE;
/*!40000 ALTER TABLE `reservas` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chofer_id` int(10) unsigned NOT NULL,
  `tipoa` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipoc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `roles_chofer_id_foreign` (`chofer_id`),
  CONSTRAINT `roles_chofer_id_foreign` FOREIGN KEY (`chofer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rolviajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rolviajes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chofer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipoa` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipoc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `rol_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `rolviajes_rol_id_foreign` (`rol_id`),
  CONSTRAINT `rolviajes_rol_id_foreign` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rolviajes` WRITE;
/*!40000 ALTER TABLE `rolviajes` DISABLE KEYS */;
/*!40000 ALTER TABLE `rolviajes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rutas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rutas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `destino_id` int(11) NOT NULL,
  `kilome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dest1` int(11) NOT NULL,
  `k1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dest2` int(11) NOT NULL,
  `k2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dest3` int(11) NOT NULL,
  `k3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dest4` int(11) NOT NULL,
  `k4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dest5` int(11) NOT NULL,
  `k5` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adicional` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `viaje_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `rutas_viaje_id_foreign` (`viaje_id`),
  CONSTRAINT `rutas_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rutas` WRITE;
/*!40000 ALTER TABLE `rutas` DISABLE KEYS */;
/*!40000 ALTER TABLE `rutas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `salidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salidas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo` int(10) unsigned NOT NULL,
  `chofer` int(10) unsigned NOT NULL,
  `lugar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `motivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `responsable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hsalida` time NOT NULL,
  `hllegada` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `salidas_vehiculo_foreign` (`vehiculo`),
  KEY `salidas_chofer_foreign` (`chofer`),
  CONSTRAINT `salidas_chofer_foreign` FOREIGN KEY (`chofer`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `salidas_vehiculo_foreign` FOREIGN KEY (`vehiculo`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `salidas` WRITE;
/*!40000 ALTER TABLE `salidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `salidas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `solicitudes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitudes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chofer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripsoli` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `solicitudes_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `solicitudes_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `solicitudes` WRITE;
/*!40000 ALTER TABLE `solicitudes` DISABLE KEYS */;
/*!40000 ALTER TABLE `solicitudes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_viaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_viaje` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `viaje_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_viaje_user_id_foreign` (`user_id`),
  KEY `user_viaje_viaje_id_foreign` (`viaje_id`),
  CONSTRAINT `user_viaje_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_viaje_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_viaje` WRITE;
/*!40000 ALTER TABLE `user_viaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_viaje` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombres` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` enum('administrador','supervisor','chofer','mecanico','encargado','mensajero') COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `insertador` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vehiculo_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehiculo_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vehiculo_user_user_id_foreign` (`user_id`),
  KEY `vehiculo_user_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `vehiculo_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `vehiculo_user_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vehiculo_user` WRITE;
/*!40000 ALTER TABLE `vehiculo_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehiculo_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vehiculo_viaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehiculo_viaje` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `viaje_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vehiculo_viaje_vehiculo_id_foreign` (`vehiculo_id`),
  KEY `vehiculo_viaje_viaje_id_foreign` (`viaje_id`),
  CONSTRAINT `vehiculo_viaje_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `vehiculo_viaje_viaje_id_foreign` FOREIGN KEY (`viaje_id`) REFERENCES `viajes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vehiculo_viaje` WRITE;
/*!40000 ALTER TABLE `vehiculo_viaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehiculo_viaje` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vehiculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehiculos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `placa` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pasajeros` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipog` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` enum('optimo','mantenimiento','desuso') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vehiculos` WRITE;
/*!40000 ALTER TABLE `vehiculos` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehiculos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `viajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `viajes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `objetivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dias` int(11) NOT NULL,
  `pasajeros` int(11) NOT NULL,
  `fecha_inicial` date NOT NULL,
  `fecha_final` date NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reserva_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `viajes_reserva_id_foreign` (`reserva_id`),
  CONSTRAINT `viajes_reserva_id_foreign` FOREIGN KEY (`reserva_id`) REFERENCES `reservas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `viajes` WRITE;
/*!40000 ALTER TABLE `viajes` DISABLE KEYS */;
/*!40000 ALTER TABLE `viajes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

