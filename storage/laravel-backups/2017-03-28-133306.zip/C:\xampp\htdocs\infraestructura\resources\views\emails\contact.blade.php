<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Documento</title>
    <link rel="stylesheet" href="">
</head>
<body>
    <p><strong>Nombre: </strong>{!! $nombre !!}</p>
    <p><strong>Correo: </strong>{!! $email !!}</p>
    <p><strong>Mensaje: </strong>{!! $mensaje !!}</p>
</body>
</html>