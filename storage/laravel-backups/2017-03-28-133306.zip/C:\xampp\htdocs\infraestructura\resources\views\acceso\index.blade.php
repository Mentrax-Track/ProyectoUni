@extends('automotores.admin')

@section('subtitulo','Acceso denegado')
    
@section('content')

    @include('alertas.success')

@stop