<?php 

return array(

    'completos' => [
        ''    => 'Seleccione un tipo de usuario',
        'administrador'     => 'administrador',
        'supervisor'        => 'supervisor',
        'chofer'            => 'chofer',
        'mecanico'          => 'mecánico',
        'encargado'         => 'encargado',
        'mensajero'         => 'mensajero',
    ]
)
?> 