<?php 

return array(

    'deps' => [
         'Potosí'    =>'Potosí',
         'Oruro'     =>'Oruro',
         'La_Paz'    =>'La Paz',
         'Pando'     =>'Pando',
         'Cochabamba'=>'Cochabamba',
         'Sucre'     =>'Sucre',
         'Tarija'    =>'Tarija',
         'Santa_Cruz'=>'Santa Cruz',
         'Beni'      =>'Beni',
    ]
)


?> 