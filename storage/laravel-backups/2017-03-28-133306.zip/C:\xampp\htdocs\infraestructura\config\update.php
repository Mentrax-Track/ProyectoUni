<?php 

return array(

    'updates' => [
        ''    => 'Seleccione un tipo de usuario',
        'chofer'            => 'chofer',
        'mecánico'          => 'mecánico',
        'encargado'         => 'encargado',
        'mensajero'         => 'mensajero',
    ]
)
?> 