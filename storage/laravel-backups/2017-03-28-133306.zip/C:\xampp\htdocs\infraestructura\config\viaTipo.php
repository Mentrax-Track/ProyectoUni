<?php 

return array(

    'viaTipos' => [
        'Viaje de Práctica'  => 'Viaje de Práctica',
        'Viaje de Inspección'=> 'Viaje de Inspección',
        'Viaje Académico'    => 'Viaje Académico',
        'Viaje de Cultura'   => 'Viaje de Cultura',
    ]
)
?> 