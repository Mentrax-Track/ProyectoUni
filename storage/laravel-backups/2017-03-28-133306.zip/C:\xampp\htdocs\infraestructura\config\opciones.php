<?php 

return array(

    'types' => [
         'Camión'   =>'Camión',
         'Camioneta'=>'Camioneta',
         'Civilian' =>'Civilian',
         'Jeep'     =>'Jeep',
         'Omnibus'  =>'Omnibus',
         'Taxi'     =>'Taxi',
         'Vagoneta' =>'Vagoneta'
    ]
)


?> 